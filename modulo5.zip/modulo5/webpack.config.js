const path = requiere('path');
const yaml = require('yamljs');
const json5 = require('json5');


module.export = {
    entry: './src/index.js',
    output: {
        filename: 'bundle.js',
        path: path.resolve(__dirname, 'dist'),
    },
    module: {
        rules: [
        {
            test: /\.css$/i,
            use: ['style-loader', 'css-loader'],

        },
        {
            test: /\.(png|jpg)$/i,
            type: 'asset/resource',

        },
        {
            test: /\.csv$/i,
            use: [ 'csv-loader'],

        },
        {
            test: /\.cs$/i,
            use: ['style-loader', 'css-loader'],

        },
    ],
 },
};