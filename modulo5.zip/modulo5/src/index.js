import _ from 'lodash';
import './estilo.css';
import imagen from './imagen.JPG';
import Datos from './datos.csv'



function componente () {
    const elemento = document.createElement('div');
    //lodash
    elemento.innerHTML = _.join(['Hola', 'webpack'], ' ');
    elemento.classList.add('hola');
    const miImagen = new Image();
    miImagen.src = imagen;
    elemento.appendChild(miImagen);
    console.log(Datos);
    return elemento;

}

document.body.appendChild(componente());